ls | wc -w | tr -d " "
